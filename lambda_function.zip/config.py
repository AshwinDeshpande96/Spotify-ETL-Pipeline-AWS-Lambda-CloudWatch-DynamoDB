class Credentials:
    def __init__(self, cid, secret):
        self.secret = secret
        self.cid = cid


creds = Credentials(
    cid="801b768250bd47fd8faa25d064fde5be",
    secret="5b1be423154c47939ea2f1af7aa2b18d"
)
