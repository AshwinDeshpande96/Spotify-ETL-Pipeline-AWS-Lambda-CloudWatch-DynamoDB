default_response = {
    "statusCode": 400,
    "headers": {
        "Content-Type": "application/json"
    },
    "body": {
        "message": "Request failed."
    }
}
